#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Ansible custom module to collect info by only providing VM name from Azure
#
# tsvetelin.maslarski-ext@ldc.com

__metaclass__ = type

ANSIBLE_METADATA = {
    'metadata_version': '3.0',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = r'''
---
module: azure_info_collector
version_added: "1.0.3"
author: "Tsvetelin Maslarski (LDC)"
short_description: Collects VM info from Azure.
description:
  - Computer name must be provided in order to collect VM info.
  - The program will brute-force search in all available subscriptions to find the VM.
  - If a VM is found the information will be outputted.
notes:
  - The following environment variables must be provided (injected via AAP credentials or vault)
  - AZURE_CLIENT_ID
  - AZURE_CLIENT_SECRET
  - AZURE_TENANT_ID
'''

EXAMPLES = r'''
- name: Collect VM info
  ldc_custom.azure_manager.azure_info_collector:
    vm_name: "CSM1KPOCVMW916"
'''

RETURN = r'''
vm:
  description: The name of the virtual machine.
  type: str
  returned: always

resource_group:
  description: The resource group the VM belongs to.
  type: str
  returned: always

subscription_id:
  description: The subscription ID the VM belongs to.
  type: str
  returned: always

power_state:
  description: The final power state after action.
  type: str
  returned: always

status:
  description: Indicates if the operation was successful.
  type: str
  returned: always
  sample: "success"

msg:
  description: Human-readable success message.
  type: str
  returned: always
'''

from ansible.module_utils.basic import AnsibleModule
import os
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from azure.identity import ClientSecretCredential, AzureAuthorityHosts
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.resource import ResourceManagementClient, SubscriptionClient


def connector(authority):
    """
    Returns a credential object for the specified Azure authority.
    """
    if authority == 'china':


        return ClientSecretCredential(
            tenant_id=os.environ.get("CHINA_TENANT_ID"),
            client_id=os.environ.get("CHINA_CLIENT_ID"),
            client_secret=os.environ.get("CHINA_CLIENT_SECRET"),
            authority=AzureAuthorityHosts.AZURE_CHINA
            # authority="https://login.chinacloudapi.cn/"
        )
    else:
        return ClientSecretCredential(
            tenant_id=os.environ.get("AZURE_TENANT_ID"),
            client_id=os.environ.get("AZURE_CLIENT_ID"),
            client_secret=os.environ.get("AZURE_CLIENT_SECRET")
        )


def get_compute_client(authority, sub_id, creds):
    # Gets the ComputeManagementClient based on the authority
    if authority == 'china':
        compute_client = ComputeManagementClient(
            creds,
            sub_id,
            base_url="https://management.chinacloudapi.cn",
            credential_scopes=["https://management.chinacloudapi.cn/.default"],
            connection_verify=False
        )
    else:
        compute_client = ComputeManagementClient(creds, sub_id)

    return compute_client

def get_sub_client(authority, creds):
    # Gets the SubscriptionClient based on the authority
    if authority == 'china':
        sub_client = SubscriptionClient(
            creds,
            base_url="https://management.chinacloudapi.cn",
            credential_scopes=["https://management.chinacloudapi.cn/.default"],
            connection_verify=False
        )
    else:
        sub_client = SubscriptionClient(creds)

    return sub_client

def get_resource_client(authority, sub_id, creds):
    # Gets the ResourceManagementClient based on the authority
    if authority == 'china':
        resource_client = ResourceManagementClient(
            creds,
            sub_id,
            base_url="https://management.chinacloudapi.cn",
            credential_scopes=["https://management.chinacloudapi.cn/.default"],
            connection_verify=False
        )
    else:
        resource_client = ResourceManagementClient(creds, sub_id)

    return resource_client

def collect_info(vm_name):

    # Define the prefixes for China-based VMs; Append more as needed
    china_prefixes = ["CSM4", "LAB4"]

    # initialize the authority based on the VM name and utilize the respective credentials
    authority = 'china' if any(p in vm_name for p in china_prefixes) else 'global'
    credentials = connector(authority)

    sub_client = get_sub_client(authority, credentials)

    # Iterate through all subscriptions to find the VM
    for sub in sub_client.subscriptions.list():
        sub_id = sub.subscription_id
        compute_client = get_compute_client(authority, sub_id, credentials)
        resource_client = get_resource_client(authority, sub_id, credentials)


        try:
            for rg in resource_client.resource_groups.list():
                for vm in compute_client.virtual_machines.list(rg.name):
                    vm_details = compute_client.virtual_machines.get(rg.name, vm.name, expand='instanceView')
                    computer_name = vm_details.os_profile.computer_name if vm_details.os_profile else None

                    # print(f"Checked: {sub_id} / {rg.name} / {vm.name} > {computer_name}")

                    if computer_name and computer_name.upper() == vm_name.upper():
                        power_state = vm_details.instance_view.statuses[1].display_status

                        return {
                            'found': True,
                            'vm': vm.name,
                            'resource_group': rg.name,
                            'subscription_id': sub_id,
                            'power_state': power_state
                        }
        except Exception:
            continue

    return {'found': False}


def main():
    module = AnsibleModule(
        argument_spec=dict(
            vm_name=dict(type='str', required=True),
        ),
        supports_check_mode=False,
    )

    vm_name = module.params['vm_name']
    result = collect_info(vm_name)

    if not result['found']:
        module.fail_json(msg=f"Couldn't find {vm_name}")
    else:
        module.exit_json(
            changed=False,
            vm=result['vm'],
            resource_group=result['resource_group'],
            subscription_id=result['subscription_id'],
            power_state=result['power_state'],
            status='success',
            msg=f"VM {result['vm']} found in {result['resource_group']} ({result['subscription_id']}) with power state {result['power_state']}"
        )


if __name__ == '__main__':
    main()
