## 1.2.2 - 2025-12-09
- Fixes
    - Removed certificate bundle setting for China endpoints to avoid SSL verification issues, since we have now a bypass for China
    - Added switches for Azure space selection (Global/China) in both modules.

## 1.1.1 - 2025-07-23
- Fixes
    - SSL certificate verification issues.
    - Combined on the execution nodes the NetScope Certificates + NetScope Root CA + LDC-IntermediatecaCert_2027.crt into ChinaChain.pem
    - Changed the logic if the node is in Global, at credential setup to unset the certificate bundle, so it uses the default one.

## 1.1.0 - 2025-06-27
- General
    - Documentation and changelog updated for clarity and accuracy.
    - Minor code clean-up and formatting improvements in both modules.
    - Added support for managing and collecting information on Azure VMs in China clouds.
    - Suppressed InsecureRequestWarning from urllib3 for unverified HTTPS requests to Azure China endpoints to keep output clean.
- azure_info_collector
    - Improved error handling and output consistency.
    - Ensured compatibility with latest Azure SDKs and Ansible best practices.
    - Added logic to detect China-based VMs by prefix and use China-specific Azure endpoints and credentials.
    - Set China-specific certificate bundle for requests to Azure China.
    - Suppressed InsecureRequestWarning for China endpoints.
- azure_power_manager
    - Enhanced inventory file parsing for edge cases.
    - Improved VM state polling logic for more reliable start/stop operations.
    - Added more robust exception handling for Azure API errors.
    - Added logic to detect China-based VMs by prefix and use China-specific Azure endpoints and credentials.
    - Set China-specific certificate bundle for requests to Azure China.
    - Suppressed InsecureRequestWarning for China endpoints.

> tsvetelin.maslarski-ext@ldc.com

## 1.0.7 - 2025-05-09
- Fixed an issue where start will take very long, due to how azure api is handling the request (it's async, invoking a wait() func which doesn't pass until the done() func)
        # Issue #18808: wait for the thread state to be gone.
        # At the end of the thread's life, after all knowledge of the thread
        # is removed from C data structures, C code releases our _tstate_lock.
        # This method passes its arguments to _tstate_lock.acquire().
        # If the lock is acquired, the C code is done, and self._stop() is
        # called.  That sets ._is_stopped to True, and ._tstate_lock to None.

## 1.0.6 - 2025-05-02
- azure_info_collector
    - Moved authentication from ClientSecretCredential to DefaultAzureCredential.
    - Improved JSON output to ensure structured results.
    - Added validation and cleaner error handling for missing VM scenarios.
- azure_power_manager
    - Added inventory file parsing logic that skips the first line if it's a PowerShell metadata line (e.g. #TYPE), improving compatibility with exported .csv files.
    - Switched to csv.DictReader from a cleaned in-memory buffer to avoid broken headers.


## 1.0.3 - 2025-04-30

- General Changes
    - DOCUMENTATION section needed to be yaml format
    - Removed local requirements.txt
    - Finilized README
    - Code clean-up
    - Changed the collection name to 'azure_manager'
    - Fixed some typos


## 1.0.0 - 2025-04-14

- Azure info collector
    - collects informations such as resource group, power state, subscription id only based on vm name
    - collected information such as the resource group is a required parameter for all ootb azure related 
        ansible modules.
