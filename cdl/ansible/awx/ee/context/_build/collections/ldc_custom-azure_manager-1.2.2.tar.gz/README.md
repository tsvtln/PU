[***Info Collector Module***](#info-collector)
[Module Information](#info-collector-module-information)
[Requirements](#info-collector-requirements)
[Example](#info-collector-example)
[Returns](#info-collector-returns)

[***Power Manager Module***](#power-manager)
[Module Information](#power-manager-module-information)
[Requirements](#power-manager-requirements)
[Examples](#power-manager-examples)
[Returns](#power-manager-returns)


# Info Collector

#### Info Collector Module Information

|                    |                              |
|--------------------|------------------------------|
| module				         | azure_info_collector         |
| version added 	    | 1.0 	                        |
| author				         | Tsvetelin Maslarski (LDC)	   |
| short description	 | Collects VM info from Azure	 |

#### Info Collector Requirements
  - Computer name must be provided in order to collect VM info.
  - The program will brute-force search in all available subscriptions to find the VM.
  - Now supports searching and collecting VM info from Azure China clouds (CSM4/LAB4 prefixes) using China-specific credentials and endpoints.
  - Automatically sets China-specific certificate bundle for secure requests to Azure China.
  - Suppresses InsecureRequestWarning from urllib3 for unverified HTTPS requests to Azure China endpoints, resulting in cleaner output.
  - If a VM is found the information will be outputted as:
```yaml
        {
            "subscriptionId": "<subscription_id>",
            "resourceGroup": "<resource_group_id>",
            "name": "vm_name",
            "status": "<power_state>"
        }
```

- The following environment variables must be provided (injected via AAP credentials or vault):
```
        AZURE_CLIENT_ID
        AZURE_CLIENT_SECRET
        AZURE_TENANT_ID
        # For China VMs:
        CHINA_CLIENT_ID
        CHINA_CLIENT_SECRET
        CHINA_TENANT_ID
```

- Example of environment injection in a playbook:
```yaml
        environment:
            AZURE_CLIENT_ID: "{{ azure_client_id }}"
            AZURE_CLIENT_SECRET: "{{ azure_client_secret }}"
            AZURE_TENANT_ID: "{{ azure_tenant_id }}"
            # For China VMs:
            CHINA_CLIENT_ID: "{{ china_prod_client_id }}"
            CHINA_CLIENT_SECRET: "{{ china_prod_client_secret }}"
            CHINA_TENANT_ID: "{{ china_prod_tenant_id }}"
```

#### Info Collector Example

```yaml
- name: Collect VM info
  ldc_custom.azure_manager.azure_info_collector:
    vm_name: "CSM1KPOCVMW916"
```

#### Info Collector Returns

```yaml
vm:
  description: The name of the virtual machine.
  type: str
  returned: always
```
```yaml
resource_group:
  description: The resource group the VM belongs to.
  type: str
  returned: always
```
```yaml
subscription_id:
  description: The subscription ID the VM belongs to.
  type: str
  returned: always
```
```yaml
power_state:
  description: The final power state after action.
  type: str
  returned: always
```
```yaml
status:
  description: Indicates if the operation was successful.
  type: str
  returned: always
  sample: "success"
```
```yaml
error:
  description: Error message if operation failed.
  type: str
  returned: when status == "failed"
```


# Power Manager

#### Power Manager Module Information
|                   |                                                                                                 |
|-------------------|-------------------------------------------------------------------------------------------------|
| module			         | 	azure_power_manager											                                                                 |
| version added 	   | 	1.0														                                                                              |
| author			         | 	Tsvetelin Maslarski (LDC) 								                                                             |
| short description | Manage Azure VM power state using inventory-based lookup 	                                      |
| full description	 | This module allows you to start, stop, or deallocate the power state of Azure virtual machines. |

#### Power Manager Requirements

  - The inventory must include the VMs subscriptionId, resourceGroup, and computerName columns.
  - Inventory stored at: 
```bash
  \\csm1gadmsto001.file.core.windows.net\global-adm-shared\indus\Inventory_reference
File name: azure_VMs_inventory-global-china.csv
```
 
 - Required parameters:
```yaml
options:
  vm_name:
    description:
      - Name of the Azure virtual machine (computerName) to manage.
    required: true
    type: str
```
```yaml
action:
    description:
      - Power action to apply to the virtual machine.
    required: true
    type: str
    choices:
      - start
      - stop
      - deallocate
```

- This module must be executed on EE node.
- Inventory file path is hardcoded inside the module as:
```bash
    /mnt/opcon-archive/Archive/7D/UPD/
```
- The inventory file is automatically resolved as:

```bash
    /mnt/opcon-archive/Archive/7D/UPD/azure_VMs_inventory-global-china-<today>.csv
```
      
- The following environment variables must be provided (injected via AAP credentials or vault):
```
 AZURE_CLIENT_ID
 AZURE_CLIENT_SECRET
 AZURE_TENANT_ID
```
- Example of environment injection in a playbook:
```yml
      environment:
        AZURE_CLIENT_ID: "{{ azure_client_id }}"
        AZURE_CLIENT_SECRET: "{{ azure_client_secret }}"
        AZURE_TENANT_ID: "{{ azure_tenant_id }}"
```


#### Power Manager Examples
```yml
 - name: Start an Azure VM
  ldc_custom.azure_manager.azure_power_manager:
    vm_name: "CSM1KPOCVMW916"
    action: "start"
```
```yml
- name: Stop a VM
  ldc_custom.azure_manager.azure_power_manager:
    vm_name: "CSM1KPOCVMW916"
    action: "deallocate"
```

#### Power Manager Returns
```yaml
vm:
  description: The name of the virtual machine.
  type: str
  returned: always
```
```yaml
resource_group:
  description: The resource group the VM belongs to.
  type: str
  returned: always
```
```yaml
subscription_id:
  description: The subscription ID the VM belongs to.
  type: str
  returned: always
```
```yaml
power_state:
  description: The final power state after action.
  type: str
  returned: always
```
```yaml
status:
  description: Indicates if the operation was successful.
  type: str
  returned: always
  sample: "success"
```
```yaml
error:
  description: Error message if operation failed.
  type: str
  returned: when status == "failed"
```